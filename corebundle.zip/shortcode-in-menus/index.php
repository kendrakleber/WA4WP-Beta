<?php

//Silence is golden