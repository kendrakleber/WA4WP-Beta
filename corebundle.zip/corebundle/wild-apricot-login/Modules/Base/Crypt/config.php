<?php

return array(
    'salt' => 'z:V6#<<-dji/rKhu',
    'password' => '84(v3;Z`xnlQJIBq',
    'iv' => ''
);